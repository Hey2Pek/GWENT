module com.example.gwent {
    requires javafx.controls;
    requires javafx.fxml;
    exports com.example.gwent;
}
